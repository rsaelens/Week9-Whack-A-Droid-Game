package org.intracode.week9

import android.content.res.Resources
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*
import kotlin.concurrent.timerTask

class MainActivity : AppCompatActivity() {


    var y:Float = 0.00F
    var x:Float = 0.00F
    var random = Random()
    var score:Int = 0
    var timer = Timer()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var imageMole = findViewById<ImageButton>(R.id.imgMole)
        var btnControl = findViewById<Button>(R.id.btnControl)
        var GameBackGround = findViewById<ConstraintLayout>(R.id.gameCanvas)
        var textScore = findViewById<TextView>(R.id.txtScore)


        imageMole.setTranslationX(-500F)
        imageMole.setTranslationY(-500F)



        btnControl.setOnClickListener{
            if (btnControl.text == "Begin"){
                Toast.makeText(this, "Tap the Little Guy to Score", Toast.LENGTH_SHORT).show ()
                btnControl.text = "Stop"
                score = 0
                txtScore.text = "Score: " + score.toString()
                imageMole.setTranslationX(-500F)
                imageMole.setTranslationY(-500F)
                timer = Timer()
                timer.schedule(timerTask {changeImage()},3000)

            }else{
                btnControl.text = "Begin"
                imageMole.setTranslationX(-500F)
                imageMole.setTranslationY(-500F)
                timer.cancel()
            }

        }

     imageMole.setOnClickListener{
            score += 100
            if (score == 500){
                timer.cancel()
                Toast.makeText(this, "You Have Won!", Toast.LENGTH_LONG).show ()
                score = 0
                btnControl.text = "Begin"
                imageMole.setTranslationX(-500F)
                imageMole.setTranslationY(-500F)
            }
            else {
                txtScore.text = "Score: " + score.toString()
            }

        }

        GameBackGround.setOnClickListener{
            println("Click")
            score -= 100
            txtScore.text = "Score: " + score.toString()
            if (score == 0 || score == -100){
                Toast.makeText(this, "Game Over", Toast.LENGTH_SHORT).show ()
                score = 0
                txtScore.text = "Score: " + score.toString()
                imageMole.setTranslationX(-500F)
                imageMole.setTranslationY(-500F)
                timer.cancel()
                btnControl.text = "Begin"

            }
        }
    }

    fun changeImage(){
        y = ((Math.random () * getScreenHeight() + 50)) .toFloat ()
        x = ((Math.random () * getScreenWidth() + 50)) .toFloat ()
        imgMole.setTranslationX(x)
        imgMole.setTranslationY(y)
        timer.schedule(timerTask {changeImage()},2000)
    }
    fun getScreenWidth(): Float {
        return Resources.getSystem().getDisplayMetrics().widthPixels / 3.0F

    }

    fun getScreenHeight(): Float {
        return Resources.getSystem().getDisplayMetrics().heightPixels / 3.0F
    }
}